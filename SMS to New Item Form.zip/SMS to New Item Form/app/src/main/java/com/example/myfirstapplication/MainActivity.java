package com.example.myfirstapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.util.StringTokenizer;

public class MainActivity extends AppCompatActivity {

    public static final String TAG = "LIFE_CYCLE_TRACING";
    TextView name, quantity, cost, description;
    ToggleButton tButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = findViewById(R.id.nameID);
        quantity = findViewById(R.id.quantityID);
        description = findViewById(R.id.descriptionID);
        cost = findViewById(R.id.costID);
        tButton = findViewById(R.id.toggleButtonID);

        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS}, 0);

        MyBroadCastReceiver myBroadCastReceiver = new MyBroadCastReceiver();

        registerReceiver(myBroadCastReceiver,new IntentFilter(SMSReceiver.SMS_FILTER));

//        restoreData();
    }

    class MyBroadCastReceiver extends BroadcastReceiver{

        @Override
        public void onReceive(Context context, Intent intent){

            String msg = intent.getStringExtra(SMSReceiver.SMS_MSG_KEY);

            StringTokenizer sT = new StringTokenizer(msg, ";");
            String Name = sT.nextToken();
            String Quantity = sT.nextToken();
            String Description = sT.nextToken();
            String Cost = sT.nextToken();
            String ToggleButtonState = sT.nextToken();

            boolean check = Boolean.valueOf(ToggleButtonState);

            name.setText(Name);
            quantity.setText(Quantity);
            description.setText(Description);
            cost.setText(Cost);
            tButton.setChecked(check);
        }
    }
/*
    public void showName() {
        String Name = name.getText().toString();
        String Quantity = quantity.getText().toString();
        String Description = description.getText().toString();
        String Cost = cost.getText().toString();

        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("name", Name);
        intent.putExtra("quantity", Quantity);
        intent.putExtra("cost", Cost);
        intent.putExtra("description", Description);

        startActivity(intent);
    }
*/
    public void showToast(View view) {

        String nameStr = name.getText().toString();

        Toast myMessage = Toast.makeText(this, "New item (" + nameStr + ") has been added", Toast.LENGTH_SHORT);
        myMessage.show();
    }

    public void onClear(View view) {
        name.setText("");
        quantity.setText("");
        description.setText("");
        cost.setText("");
        tButton.setChecked(false);
/*
        SharedPreferences sp = getSharedPreferences("MainActivity",0);
        SharedPreferences.Editor editor = sp.edit();

        editor.putString("name", "");
        editor.putString("quantity", "");
        editor.putString("cost", "");
        editor.putString("description", "");

        editor.apply();
*/
    }
/*
    protected void onSaveInstanceState(Bundle outState) {
        SharedPreferences sp = getSharedPreferences("MainActivity",0);
        SharedPreferences.Editor editor = sp.edit();

        editor.putString("name", name.getText().toString());
        editor.putString("quantity", quantity.getText().toString());
        editor.putString("cost", cost.getText().toString());
        editor.putString("description", description.getText().toString());

        editor.apply();

        super.onSaveInstanceState(outState);
        Log.i(TAG, "onSaveInstanceState");
    }
    protected void onRestoreInstanceState(Bundle inState) {

        restoreData();

        super.onRestoreInstanceState(inState);
        Log.i(TAG, "onRestoreInstanceState");
    }

    public void restoreData(){
        SharedPreferences sp = getSharedPreferences("MainActivity",0);
        SharedPreferences.Editor editor = sp.edit();

        name.setText(sp.getString("name",""));
        quantity.setText(sp.getString("quantity",""));
        cost.setText(sp.getString("cost",""));
        description.setText(sp.getString("description",""));

    }

 */

}
