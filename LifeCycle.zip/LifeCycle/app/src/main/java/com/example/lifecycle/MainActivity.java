package com.example.lifecycle;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    public static final String TAG = "LIFE_CYCLE_TRACING";
    public static final String SP_FILE_NAME = "Testing01PreferencesFile";
    public static final String EXTRA_DATA_1 = "ExtraData";

    private EditText viewDataEditText;
    private EditText nonViewDataEditText;
    private EditText persistentDataEditText;

    private String nonViewState;
    private String persistentState;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(TAG, "onCreate");
        setContentView(R.layout.activity_main);

        viewDataEditText = (EditText) findViewById(R.id.viewDataEditText);
        viewDataEditText.setShowSoftInputOnFocus(false);
        nonViewDataEditText = (EditText) findViewById(R.id.nonViewDataEditText);
        nonViewDataEditText.setShowSoftInputOnFocus(false);
        persistentDataEditText = (EditText) findViewById(R.id.persistentDataEditText);
        persistentDataEditText.setShowSoftInputOnFocus(false);
    }

    protected void onStart(){
        super.onStart();
        Log.i(TAG, "onStart");
    }
    protected void onResume() {
        super.onResume();
        Log.i(TAG, "onResume");
    }
    protected void onPause() {
        super.onPause();
        Log.i(TAG, "onPause");
    }
    protected void onStop() {
        super.onStop();
        Log.i(TAG, "onStop");
    }
    protected void onRestart() {
        super.onRestart();
        Log.i(TAG, "onRestart");
    }
    protected void onDestroy() {
        super.onDestroy();
        Log.i(TAG, "onDestroy");
    }
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.i(TAG, "onSaveInstanceState");
    }
    protected void onRestoreInstanceState(Bundle inState) {


        Log.i(TAG, "onRestoreInstanceState");
    }
    //==================================================================================
    public void setNonViewStateInstVar(View view) throws IOException{
        nonViewState = nonViewDataEditText.getText().toString();
        Log.i(TAG, "nonViewState instance var =" + nonViewState);
    }
    public void getNonViewStateInstVar(View view) throws IOException{
        nonViewDataEditText.setText(nonViewState);
        Log.i(TAG, "nonViewState instance var =" + nonViewState);
    }
    //==================================================================================
    public void setPersistentInstVarVal(View view) throws IOException{
        persistentState = persistentDataEditText.getText().toString();
        Log.i(TAG,"set persistent instance var val =" + persistentState);
    }
    public void getPersistentInstVarVal(View view) throws IOException{
        persistentDataEditText.setText(persistentState);
        Log.i(TAG,"got persistent instance var val =" + persistentState);
    }

    public void setPersistentData(View view) throws IOException{
        saveSharedPreferences();
        Log.i(TAG,"set persistent data =" + persistentState);
    }
    public void getPersistentData(View view) throws IOException{
        restoreSharedPreferences();
        Log.i(TAG,"got persistent data =" + persistentState);
    }
    //==================================================================================
    public void saveSharedPreferences(){
        SharedPreferences sp = getSharedPreferences("file1",0);
        SharedPreferences.Editor editSP = sp.edit();
        editSP.putString("spKey",persistentState);
        editSP.apply();
    }
    private void restoreSharedPreferences(){
        SharedPreferences sp = getSharedPreferences("file1",0);
        persistentState = sp.getString("spKey","default");
    }

}
